package com.videodownloader.pro

import android.app.Notification
import android.content.Context
import android.webkit.CookieManager
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import java.io.File
import java.util.concurrent.Executors

@UnstableApi
object StreamDownloadStore {
    private const val USER_AGENT = "VideoDownloaderPro/1.5"
    @Volatile private var cacheInstance: Cache? = null
    @Volatile private var managerInstance: DownloadManager? = null

    @Synchronized
    fun cache(context: Context): Cache {
        cacheInstance?.let { return it }
        val app = context.applicationContext
        val directory = File(app.getExternalFilesDir(null) ?: app.filesDir, "offline_stream_cache")
        if (!directory.exists()) directory.mkdirs()
        return SimpleCache(
            directory,
            NoOpCacheEvictor(),
            StandaloneDatabaseProvider(app)
        ).also { cacheInstance = it }
    }

    fun httpFactory(): DataSource.Factory {
        val upstream = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
        return ResolvingDataSource.Factory(upstream, ResolvingDataSource.Resolver { dataSpec: DataSpec ->
            val headers = HashMap(dataSpec.httpRequestHeaders)
            try {
                CookieManager.getInstance().getCookie(dataSpec.uri.toString())
                    ?.takeIf { it.isNotBlank() }
                    ?.let { headers["Cookie"] = it }
            } catch (_: Exception) { }
            dataSpec.withRequestHeaders(headers)
        })
    }

    fun cacheDataSourceFactory(context: Context): CacheDataSource.Factory =
        CacheDataSource.Factory().setCache(cache(context)).setUpstreamDataSourceFactory(httpFactory())

    @Synchronized
    fun manager(context: Context): DownloadManager {
        managerInstance?.let { return it }
        val app = context.applicationContext
        val manager = DownloadManager(
            app,
            StandaloneDatabaseProvider(app),
            cache(app),
            httpFactory(),
            Executors.newFixedThreadPool(3)
        )
        manager.maxParallelDownloads = 2
        return manager.also { managerInstance = it }
    }
}

@UnstableApi
class StreamDownloadService : DownloadService(
    FOREGROUND_NOTIFICATION_ID,
    DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    CHANNEL_ID,
    R.string.download_channel_name,
    R.string.download_channel_description
) {
    override fun getDownloadManager(): DownloadManager = StreamDownloadStore.manager(this)

    override fun getScheduler(): Scheduler? = null

    override fun getForegroundNotification(
        downloads: MutableList<Download>,
        notMetRequirements: Int
    ): Notification {
        return DownloadNotificationHelper(this, CHANNEL_ID).buildProgressNotification(
            this,
            android.R.drawable.stat_sys_download,
            null,
            null,
            downloads,
            notMetRequirements
        )
    }

    override fun onCreate() {
        super.onCreate()
    }

    companion object {
        const val CHANNEL_ID = "offline_media_downloads"
        private const val FOREGROUND_NOTIFICATION_ID = 4107
    }
}
