# Video Downloader Pro — Android

Version 1.5.0. This is the complete Android Studio source project, including its Gradle configuration, Android manifest, Kotlin source, resources, README, and GitHub Actions workflow template.

## Version 1.5.0 features
- Dark four-tab interface: Home, Browser, Downloads, Library.
- In-app WebView browser with back, forward, reload, address navigation, and page-load progress.
- Find video scans HTML5 `<video>` and `<source>` elements for media URLs explicitly exposed by the current page.
- Direct media-file downloads through Android DownloadManager, including WebView user-agent and cookies where available.
- Direct-file download status, progress, cancel/remove, and Play/Share for completed files.
- Local video discovery through MediaStore, thumbnail previews, and runtime media-library permission.
- Media3 ExoPlayer playback with HLS and DASH playback support, seeking, playback speed, Fit/Fill/Zoom, and fullscreen.
- HLS/DASH offline downloads through Media3 DownloadService and DownloadManager for accessible HTTPS `.m3u8` and `.mpd` streams.
- Offline stream progress, downloaded bytes, cache usage, pause/resume, remove, and Play offline.
- WebView cookies are forwarded to stream manifest/segment requests where Android exposes them.

## Important: GitHub requires one small workflow file outside the ZIP

You can keep all Android project files in **one ZIP upload**. However, GitHub Actions cannot start a workflow that exists only inside an uploaded ZIP. GitHub requires the workflow YAML to exist in the repository at `.github/workflows/android-apk.yml` before it can run.

Therefore, the one-time GitHub setup is:
1. Create an empty GitHub repository.
2. Upload this single project ZIP to the repository root and commit it.
3. In GitHub, choose **Add file → Create new file**.
4. Name the file `.github/workflows/android-apk.yml`.
5. Copy the workflow from `GITHUB_WORKFLOW_SETUP.md` (or from the included `.github/workflows/android-apk.yml`) into that file and commit.
6. Open **Actions**. The workflow finds the single ZIP in the repository root, extracts the project, and builds the APK.
7. Open the completed workflow run and download the `VideoDownloaderPro-debug-apk` artifact.

After this one-time setup, replacing the ZIP and committing it triggers a new build automatically. Keep exactly one project ZIP in the repository root.

## HLS/DASH offline downloads
1. Open an accessible HTTPS `.m3u8` (HLS) or `.mpd` (DASH) URL, or use Browser → Find video on a page that exposes the stream URL in its HTML5 video elements.
2. Choose **Download offline**.
3. Allow notification permission when prompted.
4. Open Downloads → HLS / DASH offline downloads.
5. Use Refresh to update progress. Completed items can be played offline.
6. Use Pause, Resume, or Remove to manage downloads.

The first implementation downloads all available renditions/tracks by default, so a master playlist can use substantial storage. Offline data stays in app-private storage until removed. Clearing app data or uninstalling the app deletes offline downloads.

## HLS/DASH limitations
- Supports accessible HTTPS, non-DRM streams only. It does not bypass DRM, paywalls, geo-restrictions, authentication requirements, or website rules.
- Some sites require custom headers, expiring tokens, signed URLs, or session behavior beyond WebView cookies; those streams may fail.
- Live or dynamically changing playlists may not be suitable for offline download.
- Background transfers may be affected by Android battery/background policies.
- There is no automatic cache-size eviction; remove downloads to free storage.

## App identity
- Application ID: `com.videodownloader.pro`
- Version: `1.5.0` (versionCode 5)
- Minimum Android: API 23 (Android 6.0)
- Target Android: API 35

## Build status
The source and workflow have not been validated by a successful Android Gradle build or real-device HLS/DASH test in this environment. Run the GitHub Actions build first. If it fails, share the failing log for correction.
