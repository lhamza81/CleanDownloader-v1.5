Create this file in your GitHub repository as `.github/workflows/android-apk.yml`.

GitHub Actions cannot execute a workflow stored only inside a ZIP archive; the YAML must be committed at this exact repository path once. The workflow then finds the single ZIP in the repository root, extracts it, and builds the APK.

```yaml
name: Build Android APK from project ZIP

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build:
    name: Extract project ZIP and build debug APK
    runs-on: ubuntu-latest
    steps:
      - name: Check out repository
        uses: actions/checkout@v4

      - name: Find the uploaded project ZIP
        id: project_zip
        shell: bash
        run: |
          mapfile -t zips < <(find . -maxdepth 1 -type f -iname '*.zip' -printf '%f\n' | sort)
          if [ "${#zips[@]}" -ne 1 ]; then
            echo "Expected exactly one project ZIP in the repository root; found ${#zips[@]}."
            printf '%s\n' "${zips[@]}"
            exit 1
          fi
          echo "file=${zips[0]}" >> "$GITHUB_OUTPUT"
          echo "Using project archive: ${zips[0]}"

      - name: Extract Android project
        shell: bash
        run: |
          mkdir -p "$RUNNER_TEMP/android-project"
          unzip -q "${{ steps.project_zip.outputs.file }}" -d "$RUNNER_TEMP/android-project"
          PROJECT_DIR="$(find "$RUNNER_TEMP/android-project" -type f -name settings.gradle.kts -printf '%h\n' | head -n 1)"
          if [ -z "$PROJECT_DIR" ]; then
            echo "Could not find settings.gradle.kts inside the uploaded ZIP."
            exit 1
          fi
          echo "PROJECT_DIR=$PROJECT_DIR" >> "$GITHUB_ENV"
          echo "Android project found at: $PROJECT_DIR"

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Android SDK packages
        run: sdkmanager "platforms;android-35" "build-tools;35.0.0"

      - name: Set up Gradle 8.9
        uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.9'

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: gradle --no-daemon clean assembleDebug

      - name: Verify APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: test -s app/build/outputs/apk/debug/app-debug.apk

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: VideoDownloaderPro-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 30
```
